package com.example.kilometersandmeters;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonmilestokm = (Button) findViewById(R.id.buttonmilestokm);
        buttonmilestokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textboxMiles = (EditText) findViewById(R.id.editTextMiles);
                EditText textboxkm = (EditText) findViewById(R.id.editTextkm);
                double vmiles = Double.parseDouble(textboxMiles.getText().toString());
                double vkm = vmiles / .62137;
                DecimalFormat formatval = new DecimalFormat("##.##");
                textboxkm.setText(formatval.format(vkm));

            }

            });
        Button buttonkmtomiles = (Button) findViewById(R.id.buttonkmtomiles);
        buttonkmtomiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textboxkm = (EditText) findViewById(R.id.editTextMiles);
                EditText textboxMiles = (EditText) findViewById(R.id.editTextkm);
                double vkm = Double.parseDouble(textboxkm.getText().toString());
                double vmiles = vkm * .62137;
                DecimalFormat formatval = new DecimalFormat("##.##");
                textboxMiles.setText(formatval.format(vmiles));

            }

        });


    }
}


