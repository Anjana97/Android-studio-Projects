package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.NumberPicker;

public class MainActivity extends AppCompatActivity {
    NumberPicker possibility;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        possibility = (NumberPicker) findViewById(R.id.numberpicker);
        webView = (WebView) findViewById(R.id.webview);
        String[] possibilityStrings = {
                "Coursera",
                "Udemy",
                "Android"
        };
        possibility.setDisplayedValues(possibilityStrings);
        possibility.setMinValue(0);
        possibility.setMaxValue(possibilityStrings.length - 1);
    }
    public void navigate(View v) {
        int choice = possibility.getValue();
        if (choice==0)
            webView.loadUrl("https://simple.wikipedia.org/wiki/Kerala");
        else if (choice==1)
            webView.loadUrl("https://en.wikipedia.org/wiki/Tamil_Nadu");
        else if(choice==2)
            webView.loadUrl("file:///android_asset/andhra.html");
    }
}
