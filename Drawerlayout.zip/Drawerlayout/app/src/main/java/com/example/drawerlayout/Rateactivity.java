package com.example.drawerlayout;

        import androidx.appcompat.app.AppCompatActivity;
        import android.os.Bundle;
        import android.content.Intent;
        import android.widget.TextView;

public class Rateactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rateactivity);
        Intent caller = getIntent();
        float rating =caller.getFloatExtra("nbStars", 0);
        TextView textView = (TextView) findViewById(R.id.textViewsec);
        textView.setText("Welcome to the second activity! your rating:" + rating);
    }
}